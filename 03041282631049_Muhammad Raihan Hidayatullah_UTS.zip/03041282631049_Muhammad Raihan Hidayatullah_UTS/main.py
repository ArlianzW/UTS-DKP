BATAS_KERING = 35
BATAS_BASAH = 70

# 15 data inti
data_inti = [22, 28, 34, 41, 55, 63, 72, 78, 31, 47, 66, 81, 19, 58, 69]

# 5 data tambahan
data_tambahan = [35, 70, 71, 5, 95]

data_kelembapan = data_inti + data_tambahan

KATEGORI = ["KERING", "NORMAL", "BASAH"]


def status_sensor(nilai):
    if nilai < BATAS_KERING:
        return "KERING"
    elif nilai <= BATAS_BASAH:
        return "NORMAL"
    else:
        return "BASAH"


def aksi_pompa(status):
    if status == "KERING":
        return "POMPA ON"
    return "POMPA OFF"


def rata_rata(data):
    return sum(data) / len(data)


def hitung_kategori(daftar_status):
    jumlah = {nama: 0 for nama in KATEGORI}
    for status in daftar_status:
        jumlah[status] += 1
    return jumlah


def main():
    daftar_status = []

    print("===== MONITORING =====")
    for nomor, nilai in enumerate(data_kelembapan, start=1):
        status = status_sensor(nilai)
        aksi = aksi_pompa(status)
        daftar_status.append(status)
        print(f"{nomor:02d} kelembapan = {nilai:3d} % -> {status:<6} / {aksi}")

    jumlah = hitung_kategori(daftar_status)

    print("\n===== RINGKASAN =====")
    print(f"Total data           : {len(data_kelembapan)}")
    for nama in KATEGORI:
        print(f"{nama:<20} : {jumlah[nama]}")
    print(f"Rata-rata kelembapan : {rata_rata(data_kelembapan):.1f} %")
    print(f"Maksimum kelembapan  : {max(data_kelembapan)} %")
    print(f"Minimum kelembapan   : {min(data_kelembapan)} %")


if __name__ == "__main__":
    main()